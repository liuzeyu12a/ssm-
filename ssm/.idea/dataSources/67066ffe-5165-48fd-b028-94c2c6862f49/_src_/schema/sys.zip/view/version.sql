CREATE VIEW sys.version AS
  SELECT
    '1.5.2'   AS `sys_version`,
    version() AS `mysql_version`;
